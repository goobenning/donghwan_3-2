package kr.ac.daelim.uml.zoo;

public class TigerCry implements ICry{
	public void Cry() {
		System.out.println("어흥");
	}
}
