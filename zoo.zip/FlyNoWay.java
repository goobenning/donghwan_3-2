package kr.ac.daelim.uml.zoo;

public class FlyNoWay implements iFly {

	public void fly() {
		System.out.println("날지못한다");
	}

}
