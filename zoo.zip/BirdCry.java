package kr.ac.daelim.uml.zoo;

public class BirdCry implements ICry {

public void Cry() {
	System.out.println("짹짹");
}
}
