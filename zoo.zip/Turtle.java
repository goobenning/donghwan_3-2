package kr.ac.daelim.uml.zoo;

public class Turtle extends Animal {

	public Turtle() {
	cry = new CryNoWay();
	fly = new FlyNoWay();
	
	}
	@Override
	public void display() {
	
		System.out.println("거북이");
		
	}

	@Override
	public void performCry() {
		cry.Cry();
	}
	@Override
	public void performFly() {
		fly.fly();
	}
	
}
