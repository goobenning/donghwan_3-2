package kr.ac.daelim.uml.zoo;

public interface iFly {

	public void fly();
	
}
