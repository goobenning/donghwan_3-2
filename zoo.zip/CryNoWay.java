package kr.ac.daelim.uml.zoo;

public class CryNoWay implements ICry {

	public void Cry() {
		System.out.println("울지못한다");
	}
}
