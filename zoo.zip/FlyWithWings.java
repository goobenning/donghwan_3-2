package kr.ac.daelim.uml.zoo;

public class FlyWithWings implements iFly{
	public void fly() {
		System.out.println("날개를 펄럭이면서 난다");
	}

	
}
